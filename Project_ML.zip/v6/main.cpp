#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <sstream>
#include <numeric>
#include <math.h>
#include <iomanip>
#include "data_processing.h"
#include "linear_regression.h"
#include "knn.h"

// Structure de donn�e : une feature est dans une colonne exemple : toutes les features de 0 a n pour la variable y -> [n][0], une ligne -> une nouvelle variable

int main()
{

    split_dataset dataset_split;
    int nmbr_columns = 0;
    double r_2 = 0.0;
    std::vector<double> mean_data;
    std::vector<double> zantoine;
    std::string csv = "data_reg_age_salary.csv";
    std::vector<std::string> initial_vector = csv_to_vector(csv, nmbr_columns);
    std::vector<std::vector<double> > data;
    std::vector<std::vector<double> > normalized_data;
    std::vector<std::vector<double> > last_label_colm;
    data = vector_to_dataset(initial_vector,nmbr_columns);
    normalized_data = min_max_scaler(data,nmbr_columns);
    LinearRegression linear_regression;
    last_label_colm = put_column_as_label(normalized_data,0);
    std::vector<double> test_regression;
    print_dataset(last_label_colm);
    test_regression = linear_regression.grad_descent_iter(last_label_colm,0.001);
        std::cout << test_regression[0] << ' ' << test_regression[1]<< std::endl;
    std::string csv2 = "iris2.csv";
    std::vector<std::string> initial_vector2 = csv_to_vector(csv2 , nmbr_columns );
    std::vector< std::vector <double>> data2 = vector_to_dataset(initial_vector2,3);

    //calcul du vecteur distance, prend en entr�e le dataset, la longeur et la largeur de notre fleur a estimer
    std::vector<double> distances = calcl_vecteur_distance(data2,2.8,0.6);

    int choix_k, choix_k2;
    std::cout<<"choix k ?"<<std::endl;
    std::cin>>choix_k;
    std::vector<int> ind_min=trouver_min(distances,choix_k);
    afficher_classe(data2,  ind_min,  choix_k );



    std::vector<std::vector<double>> train = split_train(data2);
    std::vector<std::vector<double>> test = split_test(data2);


    std::cout<<"choix k 2 ?"<<std::endl;
    std::cin>>choix_k2;
    int classe_predite, classe_vraie, compteur=0;
    double nb_erreur=0;
    std::vector<double> distances2;
    std::vector<int> ind_min2;
    for (int cpt=0; cpt<train[0].size(); cpt++)
    {
        distances2 = calcl_vecteur_distance(train,test[0][cpt],test[1][cpt]);
        ind_min2=trouver_min(distances2,choix_k2);
        classe_predite=retourner_classe(train,  ind_min2,  choix_k2 );
        classe_vraie=test[2][cpt];
        if (classe_predite != classe_vraie)
        {
            nb_erreur++;
        }

        compteur++;
    }
    double pourcentage_erreur, pourcentage_bon;
    pourcentage_erreur=(nb_erreur/compteur)*100;
    pourcentage_bon=((compteur-nb_erreur)/compteur)*100;
    std::cout<<"pourcentage erreur : "<<pourcentage_erreur<<"%"<<std::endl;
    std::cout<<"pourcentage bon : "<<pourcentage_bon<<"%"<<std::endl;

}
